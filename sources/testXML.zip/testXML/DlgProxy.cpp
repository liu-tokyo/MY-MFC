// DlgProxy.cpp : implementation file
//

#include "stdafx.h"
#include "testXML.h"
#include "DlgProxy.h"
#include "testXMLDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestXMLDlgAutoProxy

IMPLEMENT_DYNCREATE(CTestXMLDlgAutoProxy, CCmdTarget)

CTestXMLDlgAutoProxy::CTestXMLDlgAutoProxy()
{
	EnableAutomation();
	
	// To keep the application running as long as an automation 
	//	object is active, the constructor calls AfxOleLockApp.
	AfxOleLockApp();

	// Get access to the dialog through the application's
	//  main window pointer.  Set the proxy's internal pointer
	//  to point to the dialog, and set the dialog's back pointer to
	//  this proxy.
	ASSERT (AfxGetApp()->m_pMainWnd != NULL);
	ASSERT_VALID (AfxGetApp()->m_pMainWnd);
	ASSERT_KINDOF(CTestXMLDlg, AfxGetApp()->m_pMainWnd);
	m_pDialog = (CTestXMLDlg*) AfxGetApp()->m_pMainWnd;
	m_pDialog->m_pAutoProxy = this;
}

CTestXMLDlgAutoProxy::~CTestXMLDlgAutoProxy()
{
	// To terminate the application when all objects created with
	// 	with automation, the destructor calls AfxOleUnlockApp.
	//  Among other things, this will destroy the main dialog
	if (m_pDialog != NULL)
		m_pDialog->m_pAutoProxy = NULL;
	AfxOleUnlockApp();
}

void CTestXMLDlgAutoProxy::OnFinalRelease()
{
	// When the last reference for an automation object is released
	// OnFinalRelease is called.  The base class will automatically
	// deletes the object.  Add additional cleanup required for your
	// object before calling the base class.

	CCmdTarget::OnFinalRelease();
}

BEGIN_MESSAGE_MAP(CTestXMLDlgAutoProxy, CCmdTarget)
	//{{AFX_MSG_MAP(CTestXMLDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CTestXMLDlgAutoProxy, CCmdTarget)
	//{{AFX_DISPATCH_MAP(CTestXMLDlgAutoProxy)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_ITestXML to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {CDBF01A4-D862-4053-8092-AF3AD5D37038}
static const IID IID_ITestXML =
{ 0xcdbf01a4, 0xd862, 0x4053, { 0x80, 0x92, 0xaf, 0x3a, 0xd5, 0xd3, 0x70, 0x38 } };

BEGIN_INTERFACE_MAP(CTestXMLDlgAutoProxy, CCmdTarget)
	INTERFACE_PART(CTestXMLDlgAutoProxy, IID_ITestXML, Dispatch)
END_INTERFACE_MAP()

// The IMPLEMENT_OLECREATE2 macro is defined in StdAfx.h of this project
// {AEA4BE0A-1649-4D0C-B899-01B5A21B2410}
IMPLEMENT_OLECREATE2(CTestXMLDlgAutoProxy, "TestXML.Application", 0xaea4be0a, 0x1649, 0x4d0c, 0xb8, 0x99, 0x1, 0xb5, 0xa2, 0x1b, 0x24, 0x10)

/////////////////////////////////////////////////////////////////////////////
// CTestXMLDlgAutoProxy message handlers
